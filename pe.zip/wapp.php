<a href="https://wa.me/966554377469" class="whatsapp-float" target="_blank">
  <img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp" />
</a>


<style>


.whatsapp-float {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 100;
  background-color: #25d366;
  padding: 10px;
  border-radius: 50%;
  box-shadow: 0 4px 6px rgba(0,0,0,0.2);
  transition: transform 0.3s;
}

.whatsapp-float:hover {
  transform: scale(1.1);
}

.whatsapp-float img {
  width: 40px;
  height: 40px;
}




</style>